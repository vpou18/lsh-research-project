touch NEWS README AUTHORS ChangeLog
autoreconf --force --install
rm -rf *.cache